package com.hexaware.Book.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hexaware.Book.Entity.Book;
import com.hexaware.Book.Repository.BookRepository;

@Service
public class BookService {
	@Autowired
    private BookRepository repo;

    public List<Book> getAllBooks() {
        return repo.findAll();
    }

    public Book getBookByIsbn(String isbn) {
        return repo.findById(isbn).orElse(null);
    }

    public Book addBook(Book book) {
        return repo.save(book);
    }

    public Book updateBook(String isbn, Book updated) {
        if (repo.existsById(isbn)) {
            updated.setIsbn(isbn);
            return repo.save(updated);
        }
        return null;
    }

    public String deleteBook(String isbn) {
        if (repo.existsById(isbn)) {
            repo.deleteById(isbn);
            return "Book deleted";
        }
        return "Book not found";
    }
}
