package com.hexaware.Book;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Optional;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.hexaware.Book.Entity.Book;
import com.hexaware.Book.Repository.BookRepository;

@SpringBootTest
class BookApplicationTests {
	 @Autowired
	    private BookRepository bookRepository;

	    private Book testBook;

	    @BeforeEach
	    void setup() {
	        testBook = new Book();
	        testBook.setIsbn("2024202509");
	        testBook.setTitle("Twisted love");
	        testBook.setAuthor("Ana Huang");
	        testBook.setPublicationYear(2024);

	        bookRepository.save(testBook);
	    }

	    @Test
	    void testAddBook() {
	        Optional<Book> book = bookRepository.findById("2024202509");
	        assertTrue(book.isPresent());
	        assertEquals("Twisted love", book.get().getTitle());
	    }

	    @Test
	    void testFindById() {
	        Book found = bookRepository.findById("2024202509").orElse(null);
	        assertNotNull(found);
	        assertEquals("Ana Huang", found.getAuthor());
	    }

	    @Test
	    void testUpdateBook() {
	        Book updatedBook = bookRepository.findById("2024202509").orElse(null);
	        assertNotNull(updatedBook);
	        updatedBook.setTitle("Updated Book");
	        bookRepository.save(updatedBook);

	        Book found = bookRepository.findById("2024202509").orElse(null);
	        assertEquals("Updated Book", found.getTitle());
	    }

	    @Test
	    void testDeleteBook() {
	        bookRepository.deleteById("2024202509");
	        assertFalse(bookRepository.findById("2024202509").isPresent());
	    }

	    @Test
	    void testGetAllBooks() {
	        var books = bookRepository.findAll();
	        assertFalse(books.isEmpty());
	    }

	    @Test
	    void testAllArgsConstructor() {
	        Book book = new Book("2222333344", "Core Java", "Diya", 2025);

	        assertEquals("2222333344", book.getIsbn());
	        assertEquals("Core Java", book.getTitle());
	        assertEquals("Diya", book.getAuthor());
	        assertEquals(2025, book.getPublicationYear());
	    }

	    @Test
	    void testGettersAndSetters() {
	        Book book = new Book();
	        book.setIsbn("99998887");
	        book.setTitle("Spring core Book");
	        book.setAuthor("Dhruv");
	        book.setPublicationYear(2023);

	        assertEquals("99998887", book.getIsbn());
	        
	        assertEquals("Spring core Book", book.getTitle());
	        assertEquals("Dhruv", book.getAuthor());
	        assertEquals(2023, book.getPublicationYear());
	    }

	    @AfterEach
	    void cleanUp() {
	        bookRepository.deleteAll();
	    }
	    
}
