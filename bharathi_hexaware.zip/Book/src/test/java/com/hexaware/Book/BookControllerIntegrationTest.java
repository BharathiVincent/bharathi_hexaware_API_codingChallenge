package com.hexaware.Book;

import com.hexaware.Book.Entity.Book;
import com.hexaware.Book.Service.BookService;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.*;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class BookControllerIntegrationTest {
	 @LocalServerPort
	    private int port;

	    @Autowired
	    private TestRestTemplate restTemplate;

	    private String getBaseUrl() {
	        return "http://localhost:" + port + "/api/books";
	    }

	    @Test
	    @Order(1)
	    public void testAddBook() {
	        Book book = new Book("111", "Java Basics", "John", 350);

	        ResponseEntity<Book> response = restTemplate.postForEntity(getBaseUrl(), book, Book.class);

	        assertEquals(HttpStatus.OK, response.getStatusCode());
	        assertNotNull(response.getBody());
	        assertEquals("Java Basics", response.getBody().getTitle());
	    }
	    @Test
	    @Order(2)
	    public void testGetAllBooks() {
	        ResponseEntity<Book[]> response = restTemplate.getForEntity(getBaseUrl(), Book[].class);
	        assertEquals(HttpStatus.OK, response.getStatusCode());

	        Book[] books = response.getBody();
	        assertTrue(books.length > 0);
	    }

	    @Test
	    @Order(3)
	    public void testGetBookByIsbn() {
	        ResponseEntity<Book> response = restTemplate.getForEntity(getBaseUrl() + "/111", Book.class);

	        assertEquals(HttpStatus.OK, response.getStatusCode());
	        assertEquals("Java Basics", response.getBody().getTitle());
	    }

	    @Test
	    @Order(4)
	    public void testUpdateBook() {
	        Book updated = new Book("111", "Advanced Java", "John Updated", 450);
	        HttpEntity<Book> requestUpdate = new HttpEntity<>(updated);

	        ResponseEntity<Book> response = restTemplate.exchange(
	                getBaseUrl() + "/111", HttpMethod.PUT, requestUpdate, Book.class);

	        assertEquals(HttpStatus.OK, response.getStatusCode());
	        assertEquals("Advanced Java", response.getBody().getTitle());
	    }

	    @Test
	    @Order(5)
	    public void testDeleteBook() {
	        ResponseEntity<String> response = restTemplate.exchange(
	                getBaseUrl() + "/111", HttpMethod.DELETE, null, String.class);

	        assertEquals(HttpStatus.OK, response.getStatusCode());
	        assertEquals("Book deleted", response.getBody());
	    }

}
